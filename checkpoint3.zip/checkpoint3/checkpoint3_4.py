a={}
b=input('type the last number of your square numbers sequence')
for i in range (0,int(b)+1):
    a[i]=int(i)**2
print(a)   
