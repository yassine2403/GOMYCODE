n=str( input("Enter a number"))
nn= n+n
nnn= n+n+n
finaln=int(n)
finalnn=int(nn)
finalnnn=int(nnn)
print(finaln + finalnn +finalnnn)
