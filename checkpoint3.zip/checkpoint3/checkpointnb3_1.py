

from numpy import *
liste=[2,3,8]
a=prod(liste)
print(a)

    
    
