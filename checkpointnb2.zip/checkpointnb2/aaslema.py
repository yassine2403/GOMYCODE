firstname=input("write ur fn ")
lastname=input("write ur ln not natural log")
print(lastname+firstname)
    
