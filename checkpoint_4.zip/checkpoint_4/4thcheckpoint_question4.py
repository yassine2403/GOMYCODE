liste=[]
a=int(input('enter the number of elements in your list'))
for i in range (a):
    element=str(input("enter a word"))
    liste.append(element)



print(sorted(liste))

