import numpy as np
##liste=[]
##a=input("total elements in your number list")

##def func():
##    for i in range (int(a)):
##        liste.append(int(input("enter a number")))
##        print(liste)
##    print(sum(liste))

##def func2():
##    for i in range (int(a)):
##        liste.append(int(input("enter a number")))
##        print(liste)
##    print(np.prod(liste))
'''question3_3'''
##listedebase=[2,4,6,17]
##listeeven=[]
##listeodd=[]
##def Multiply(L):
##    print(np.prod(L))
##def Sum(L):
##    print(sum(L))
##
##for i in range (len(listedebase)):
##    if i%2==0:
##        listeeven.append(listedebase[i])
##    else:
##        listeodd.append(listedebase[i])
##Multiply(listeodd)
##Sum(listeeven)

