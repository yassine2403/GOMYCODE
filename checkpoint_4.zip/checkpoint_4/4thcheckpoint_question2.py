def rdfunc(a,b):
    x=a+b
    y=a-b
    print(x,y)
rdfunc(50,30)
