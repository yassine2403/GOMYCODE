import numpy as np
a=int(input('enter an element of ur list'))
b=int(input('enter an element of ur list'))
c=int(input('enter an element of ur list'))
d=int(input('enter an element of ur list'))
x=np.array([[a,b],[c,d]])
print(x.tolist())
