a=input("Type a number")
if int(a)%2==0:
    print(a+"is even")
else:
    print(a + "is odd")
