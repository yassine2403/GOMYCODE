a=int(input("type price"))
if a>500:
    na=a*1/2
if a>=200 and a<500:
    na=a*7/10
if a<200:
    na=a*9/10
print(na)
