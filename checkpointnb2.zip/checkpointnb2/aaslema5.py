import math
x=input("enter a number ")
print("the factorial of ur number is "+str(math.factorial(int(x))))
