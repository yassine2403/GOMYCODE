a=input("type a string")
e=""
for i in range (len(a)):
    if i%2==0:
        e=e+a[i]
print(e)
